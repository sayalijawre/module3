/*import React from 'react';
import Mall from './mall';
const myContext=React.createContext();

class Screen extends React.Component{
    state={
            screen1:'Tiger',
            screen2:'Cheetah',
            screen3:'Lion'
        
    }
   
    render(){
        return(
            <div>
                <myContext.Provider value={this.state.list}></myContext.Provider>
                <Mall/>
            </div>
        )
    }
}

export default Screen;*/




import React from 'react';

export const LocaleContext = React.createContext();

class LocaleProvider extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list:{
        s1: 'Tiger',
        s2:'Cheetah',
        s3:'Lion',
        sh1: '9 PM',
        sh2:'1 PM',
        sh3:'5 PM'
      }
    };
  }

  render() {
    return (
      <LocaleContext.Provider value={this.state}>
        {this.props.children}
      </LocaleContext.Provider>
    );
  }
}

export default LocaleProvider;