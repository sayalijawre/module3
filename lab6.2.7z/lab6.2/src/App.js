import React, { Component } from 'react';
import Header from './components/header';
import Taskbar from './components/taskbar';
import Tasklists from './components/tasklists';

class App extends Component {
  render() {
    return (
     <div>
       <Header/>
       <Taskbar/>
       <Tasklists/>
     </div>
    )
  }
}

export default App;
