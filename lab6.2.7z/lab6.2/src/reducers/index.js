import {combineReducers} from 'redux';

const taskreducer=(state=[],action)=>{
    switch(action.type)
    {
        case 'ADD_TASK':
        state=state.concat(action.payload);
        break;
    }
return state;
},
reducers=combineReducers({
    tasks:taskreducer
});

export default reducers;